import { Hero } from '@/components/home/hero'
import { Marquee } from '@/components/home/marquee'
import { About } from '@/components/home/about'
import { MenuPreview } from '@/components/home/menu-preview'
import { Gallery } from '@/components/home/gallery'
import { Testimonials } from '@/components/home/testimonials'
import { CTA } from '@/components/home/cta'
import { CalendlyBadge } from '@/components/home/calendly-badge'

export default function HomePage() {
  return (
    <main>
      <Hero />
      <Marquee />
      <About />
      <MenuPreview />
      <Gallery />
      <Testimonials />
      <CTA />
      <CalendlyBadge />
    </main>
  )
}
