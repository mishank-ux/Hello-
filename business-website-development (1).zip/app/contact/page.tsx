import type { Metadata } from 'next'
import { Phone, Mail, MapPin, Clock, ArrowUpRight } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { ContactForm } from '@/components/contact/contact-form'
import { WhatsAppIcon } from '@/components/brand-icons'
import {
  business,
  telUrl,
  whatsappUrl,
  mapsDirectionsUrl,
  mapsEmbedUrl,
} from '@/lib/business'

export const metadata: Metadata = {
  title: 'Contact & Visit',
  description: `Find ${business.name} at ${business.address.line1}. Call, WhatsApp, or send us a message — we’d love to hear from you.`,
}

export default function ContactPage() {
  return (
    <main>
      <section className="mx-auto w-full max-w-6xl px-5 pb-6 pt-12 sm:px-8 sm:pt-16">
        <Reveal as="p" className="text-sm font-semibold uppercase tracking-widest text-primary">
          Say hello
        </Reveal>
        <Reveal as="h1" delay={60} className="mt-3 max-w-3xl font-display text-[clamp(2.5rem,7vw,4.25rem)] font-semibold leading-[0.98] tracking-tight text-foreground text-balance">
          Come in, or reach out.
        </Reveal>
        <Reveal as="p" delay={120} className="mt-4 max-w-xl text-pretty leading-relaxed text-muted-foreground">
          Questions, bookings, big orders or good ideas — we’re all ears. Here’s every way to find
          {' '}
          {business.name}.
        </Reveal>
      </section>

      <section className="mx-auto w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:gap-14">
          {/* Details + quick actions */}
          <div className="flex flex-col gap-4">
            <Reveal className="grid gap-4 sm:grid-cols-2">
              <a
                href={telUrl}
                className="group flex flex-col justify-between rounded-2xl border border-border bg-card p-5 transition-transform hover:-translate-y-1"
              >
                <Phone className="size-5 text-primary" />
                <div className="mt-6">
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Call</p>
                  <p className="mt-1 font-semibold text-foreground">{business.phone}</p>
                </div>
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col justify-between rounded-2xl border border-border bg-card p-5 transition-transform hover:-translate-y-1"
              >
                <WhatsAppIcon className="size-5 text-whatsapp" />
                <div className="mt-6">
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">WhatsApp</p>
                  <p className="mt-1 font-semibold text-foreground">Chat with us</p>
                </div>
              </a>
              <a
                href={`mailto:${business.email}`}
                className="group flex flex-col justify-between rounded-2xl border border-border bg-card p-5 transition-transform hover:-translate-y-1"
              >
                <Mail className="size-5 text-primary" />
                <div className="mt-6">
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Email</p>
                  <p className="mt-1 break-all font-semibold text-foreground">{business.email}</p>
                </div>
              </a>
              <div className="flex flex-col justify-between rounded-2xl border border-border bg-card p-5">
                <Clock className="size-5 text-primary" />
                <div className="mt-6">
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Hours</p>
                  {business.hours.map((h) => (
                    <p key={h.days} className="mt-1 text-sm font-medium text-foreground">
                      <span className="text-muted-foreground">{h.days}</span> {h.time}
                    </p>
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal delay={80}>
              <a
                href={mapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-start gap-3 rounded-2xl border border-border bg-card p-5 transition-transform hover:-translate-y-1"
              >
                <MapPin className="mt-0.5 size-5 shrink-0 text-primary" />
                <div className="flex-1">
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Find us</p>
                  <p className="mt-1 font-medium text-foreground">
                    {business.address.line1}, {business.address.line2}
                  </p>
                  <span className="mt-1 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                    Get directions
                    <ArrowUpRight className="size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </span>
                </div>
              </a>
            </Reveal>
          </div>

          {/* Form */}
          <Reveal delay={100} className="rounded-[2rem] border border-border bg-secondary/40 p-6 sm:p-8">
            <h2 className="font-display text-2xl font-semibold text-foreground sm:text-3xl">
              Send us a message
            </h2>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Fill this in and we’ll reply as soon as we’re off the espresso machine.
            </p>
            <div className="mt-6">
              <ContactForm />
            </div>
          </Reveal>
        </div>
      </section>

      {/* Map */}
      <section className="mx-auto w-full max-w-6xl px-5 pb-20 sm:px-8">
        <Reveal className="overflow-hidden rounded-[2rem] border border-border">
          <iframe
            title={`Map to ${business.name}`}
            src={mapsEmbedUrl}
            width="100%"
            height="420"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="block w-full grayscale-[0.15]"
          />
        </Reveal>
      </section>
    </main>
  )
}
