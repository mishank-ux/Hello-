import type { Metadata } from 'next'
import Link from 'next/link'
import { Phone, ArrowRight, Clock } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { WhatsAppIcon } from '@/components/brand-icons'
import { menu, services } from '@/lib/menu'
import { business, telUrl, whatsappUrl } from '@/lib/business'

export const metadata: Metadata = {
  title: 'Menu & Services',
  description: `The full ${business.name} menu — specialty coffee, all-day brunch, fresh bakes, plus catering and private event hire.`,
}

export default function ServicesPage() {
  return (
    <main>
      {/* Page header */}
      <section className="mx-auto w-full max-w-6xl px-5 pb-6 pt-12 sm:px-8 sm:pt-16">
        <Reveal as="p" className="text-sm font-semibold uppercase tracking-widest text-primary">
          Menu &amp; Services
        </Reveal>
        <Reveal as="h1" delay={60} className="mt-3 max-w-3xl font-display text-[clamp(2.5rem,7vw,4.25rem)] font-semibold leading-[0.98] tracking-tight text-foreground text-balance">
          Everything we pour, plate and bake.
        </Reveal>
        <Reveal as="p" delay={120} className="mt-4 max-w-xl text-pretty leading-relaxed text-muted-foreground">
          Prices include taxes. Menu rotates with the seasons, so expect a few happy surprises.
          Something you don’t see? Just ask.
        </Reveal>
        <Reveal delay={160} className="mt-5 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground">
          <Clock className="size-4 text-primary" />
          {business.hours.map((h) => `${h.days} ${h.time}`).join('  ·  ')}
        </Reveal>
      </section>

      {/* Menu categories */}
      <section className="mx-auto w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
        <div className="flex flex-col gap-14">
          {menu.map((cat) => (
            <div key={cat.id}>
              <Reveal className="flex flex-col gap-1 border-b border-border pb-4">
                <h2 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
                  {cat.title}
                </h2>
                <p className="text-sm text-muted-foreground">{cat.blurb}</p>
              </Reveal>

              <div className="mt-6 grid gap-x-10 gap-y-6 sm:grid-cols-2">
                {cat.items.map((item, i) => (
                  <Reveal
                    key={item.name}
                    delay={i * 50}
                    className="flex items-baseline gap-3"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-foreground">{item.name}</h3>
                        {item.tag && (
                          <span className="rounded-full bg-butter px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-butter-foreground">
                            {item.tag}
                          </span>
                        )}
                      </div>
                      <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">
                        {item.description}
                      </p>
                    </div>
                    <div
                      aria-hidden
                      className="h-px flex-1 translate-y-[-3px] border-b border-dashed border-border"
                    />
                    <span className="shrink-0 font-semibold text-primary">{item.price}</span>
                  </Reveal>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Services */}
      <section className="bg-card">
        <div className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
          <Reveal as="p" className="text-sm font-semibold uppercase tracking-widest text-primary">
            Beyond the counter
          </Reveal>
          <Reveal as="h2" delay={60} className="mt-3 max-w-2xl font-display text-4xl font-semibold tracking-tight text-foreground sm:text-5xl text-balance">
            More than a coffee run
          </Reveal>

          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {services.map((s, i) => (
              <Reveal
                key={s.title}
                delay={i * 90}
                className="flex flex-col rounded-2xl border border-border bg-background p-7 transition-transform hover:-translate-y-1"
              >
                <span className="font-display text-3xl font-semibold text-primary tabular-nums">
                  0{i + 1}
                </span>
                <h3 className="mt-4 font-display text-2xl font-semibold text-foreground">
                  {s.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {s.description}
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
        <Reveal className="flex flex-col items-start justify-between gap-6 rounded-[2rem] border border-border bg-secondary/50 px-6 py-10 sm:flex-row sm:items-center sm:px-12">
          <div>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
              Hungry now?
            </h2>
            <p className="mt-2 text-muted-foreground">
              Call to reserve a table or message us to place an order for pickup.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <a
              href={telUrl}
              className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-105 active:scale-95"
            >
              <Phone className="size-4" />
              Call Now
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-whatsapp px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:scale-105 active:scale-95"
            >
              <WhatsAppIcon className="size-4" />
              Order on WhatsApp
            </a>
            <Link
              href="/contact"
              className="group inline-flex items-center gap-2 rounded-full border border-foreground/15 px-6 py-3.5 text-sm font-semibold text-foreground transition-colors hover:border-foreground/30"
            >
              Directions
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
          </div>
        </Reveal>
      </section>
    </main>
  )
}
