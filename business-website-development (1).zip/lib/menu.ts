/**
 * PLACEHOLDER menu & services — generated for a Gen-Z coffee cafe.
 * Swap names, descriptions and prices for your real offerings.
 * Prices are in INR (₹).
 */

export type MenuItem = {
  name: string
  description: string
  price: string
  tag?: string
}

export type MenuCategory = {
  id: string
  title: string
  blurb: string
  items: MenuItem[]
}

export const menu: MenuCategory[] = [
  {
    id: 'coffee',
    title: 'Specialty Coffee',
    blurb: 'Single-origin beans, roasted in small batches, pulled by people who care.',
    items: [
      { name: 'House Espresso', description: 'Double shot, chocolatey and bold.', price: '₹120' },
      { name: 'Flat White', description: 'Silky microfoam, 6oz, no fuss.', price: '₹180', tag: 'Popular' },
      { name: 'Filter Pour-Over', description: 'Rotating single origin, brewed to order.', price: '₹220' },
      { name: 'Cold Brew', description: '18-hour steep, smooth and low-acid.', price: '₹210' },
    ],
  },
  {
    id: 'brunch',
    title: 'All-Day Brunch',
    blurb: 'Comfort plates with a desi twist, served start to close.',
    items: [
      { name: 'Masala Egg Toast', description: 'Sourdough, spiced scramble, microgreens.', price: '₹260', tag: 'Chef’s pick' },
      { name: 'Big Brekkie Bowl', description: 'Eggs, beans, greens, roast tomato, toast.', price: '₹340' },
      { name: 'Paneer Tikka Wrap', description: 'Smoky paneer, mint slaw, house sauce.', price: '₹280' },
      { name: 'Avo Smash', description: 'Avocado, chilli oil, feta, seeded toast.', price: '₹300' },
    ],
  },
  {
    id: 'bakery',
    title: 'Bakery & Desserts',
    blurb: 'Baked in-house every morning. Gone by evening.',
    items: [
      { name: 'Butter Croissant', description: 'Laminated for two days, flaky and gold.', price: '₹140' },
      { name: 'Biscoff Basque', description: 'Burnt cheesecake, cookie crumble.', price: '₹260', tag: 'Popular' },
      { name: 'Banana Bread', description: 'Toasted, with brown-butter drizzle.', price: '₹160' },
      { name: 'Choc Chip Cookie', description: 'Sea salt, gooey centre, always warm.', price: '₹120' },
    ],
  },
  {
    id: 'chai-coolers',
    title: 'Chai & Coolers',
    blurb: 'For the days coffee isn’t the mood.',
    items: [
      { name: 'Kadak Masala Chai', description: 'Slow-boiled, proper strong.', price: '₹90' },
      { name: 'Matcha Latte', description: 'Ceremonial grade, iced or hot.', price: '₹230' },
      { name: 'Kokum Cooler', description: 'Tangy, refreshing, house-made.', price: '₹170' },
      { name: 'Nimbu Soda', description: 'Fizzy, salty-sweet, classic.', price: '₹110' },
    ],
  },
]

export type Service = {
  title: string
  description: string
}

export const services: Service[] = [
  {
    title: 'Dine-in & Takeaway',
    description:
      'Grab a table, work all afternoon on free Wi-Fi, or take your order to go. Every seat is a good seat.',
  },
  {
    title: 'Private Events & Hire',
    description:
      'Birthdays, launches, listening parties — book the space and we’ll handle the food, coffee and vibe.',
  },
  {
    title: 'Catering & Bulk Orders',
    description:
      'Office breakfasts, bulk brews and dessert boxes delivered across the city. Order a day ahead.',
  },
]
