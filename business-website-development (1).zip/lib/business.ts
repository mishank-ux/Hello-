/**
 * ============================================================
 *  EDIT YOUR BUSINESS DETAILS HERE
 *  Everything below is PLACEHOLDER content — replace it with
 *  your real details. All values marked "PLACEHOLDER" are used
 *  across every page (nav, hero, footer, Call/WhatsApp buttons).
 * ============================================================
 */

export const business = {
  // PLACEHOLDER — your cafe name
  name: 'ADDA',
  fullName: 'ADDA — Coffee & Kitchen',
  tagline: 'your daily hangout, brewed right',

  // PLACEHOLDER — one-liner used in metadata + hero subtext
  description:
    'A Gen-Z neighbourhood cafe serving specialty coffee, all-day brunch and good vibes.',

  // PLACEHOLDER — replace with your real number in international format.
  // `phone` is what users see. `phoneHref` is used for tel: links (no spaces).
  phone: '+91 98765 43210',
  phoneHref: '+919876543210',

  // PLACEHOLDER — WhatsApp number, digits only, with country code, NO "+".
  // Example for India: 919876543210
  whatsapp: '919876543210',

  // PLACEHOLDER — email
  email: 'hello@addacafe.in',

  // PLACEHOLDER — address
  address: {
    line1: '12 Church Street',
    line2: 'Ashok Nagar, Bengaluru, Karnataka 560001',
    // Used for the "Get Directions" link + embedded map query
    mapQuery: 'Church Street, Ashok Nagar, Bengaluru, Karnataka 560001',
  },

  // PLACEHOLDER — opening hours
  hours: [
    { days: 'Mon – Thu', time: '8:00 AM – 10:30 PM' },
    { days: 'Fri – Sun', time: '8:00 AM – 11:30 PM' },
  ],

  // PLACEHOLDER — social links (leave "" to hide)
  socials: {
    instagram: 'https://instagram.com',
    facebook: 'https://facebook.com',
  },
} as const

// Pre-filled WhatsApp message
export const whatsappMessage = `Hi, I'd like to know more about ${business.name}`

export const whatsappUrl = `https://wa.me/${business.whatsapp}?text=${encodeURIComponent(
  whatsappMessage,
)}`

export const telUrl = `tel:${business.phoneHref}`

export const mapsDirectionsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  business.address.mapQuery,
)}`

// Google Maps embed (keyless). Uses the address query above.
export const mapsEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(
  business.address.mapQuery,
)}&output=embed`
