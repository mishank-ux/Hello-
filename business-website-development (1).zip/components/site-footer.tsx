import Link from 'next/link'
import { Phone, Mail, MapPin } from 'lucide-react'
import {
  business,
  telUrl,
  mapsDirectionsUrl,
  whatsappUrl,
} from '@/lib/business'
import {
  WhatsAppIcon,
  InstagramIcon,
  FacebookIcon,
} from '@/components/brand-icons'

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 bg-secondary/40">
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="font-display text-2xl font-semibold text-foreground">
            {business.name}
            <span className="text-primary">.</span>
          </p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted-foreground">
            {business.description}
          </p>
          <div className="mt-5 flex items-center gap-3">
            <a
              href={business.socials.instagram}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="inline-flex size-10 items-center justify-center rounded-full border border-border text-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              <InstagramIcon className="size-5" />
            </a>
            <a
              href={business.socials.facebook}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="inline-flex size-10 items-center justify-center rounded-full border border-border text-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              <FacebookIcon className="size-5" />
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="inline-flex size-10 items-center justify-center rounded-full border border-border text-foreground transition-colors hover:bg-whatsapp hover:text-white"
            >
              <WhatsAppIcon className="size-5" />
            </a>
          </div>
        </div>

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Explore
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li>
              <Link href="/" className="text-foreground/90 transition-colors hover:text-primary">
                Home
              </Link>
            </li>
            <li>
              <Link href="/services" className="text-foreground/90 transition-colors hover:text-primary">
                Menu &amp; Services
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-foreground/90 transition-colors hover:text-primary">
                Contact
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Visit &amp; Reach us
          </h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li>
              <a
                href={mapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-2.5 text-foreground/90 transition-colors hover:text-primary"
              >
                <MapPin className="mt-0.5 size-4 shrink-0 text-primary" />
                <span>
                  {business.address.line1}, {business.address.line2}
                </span>
              </a>
            </li>
            <li>
              <a href={telUrl} className="flex items-center gap-2.5 text-foreground/90 transition-colors hover:text-primary">
                <Phone className="size-4 shrink-0 text-primary" />
                {business.phone}
              </a>
            </li>
            <li>
              <a
                href={`mailto:${business.email}`}
                className="flex items-center gap-2.5 text-foreground/90 transition-colors hover:text-primary"
              >
                <Mail className="size-4 shrink-0 text-primary" />
                {business.email}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border/60">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-5 py-5 text-xs text-muted-foreground sm:flex-row sm:px-8">
          <p>
            © {new Date().getFullYear()} {business.fullName}. All rights reserved.
          </p>
          <p>{business.tagline}</p>
        </div>
      </div>
    </footer>
  )
}
