'use client'

import { useState } from 'react'
import { Send, Check } from 'lucide-react'
import { business } from '@/lib/business'
import { WhatsAppIcon } from '@/components/brand-icons'
import { cn } from '@/lib/utils'

type Errors = Partial<Record<'name' | 'contact' | 'message', string>>

const fieldClass =
  'w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20'

export function ContactForm() {
  const [errors, setErrors] = useState<Errors>({})
  const [sent, setSent] = useState(false)

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    const data = new FormData(form)
    const name = (data.get('name') as string)?.trim()
    const contact = (data.get('contact') as string)?.trim()
    const message = (data.get('message') as string)?.trim()

    const nextErrors: Errors = {}
    if (!name) nextErrors.name = 'Please tell us your name.'
    if (!contact) nextErrors.contact = 'Add a phone number or email so we can reply.'
    if (!message) nextErrors.message = 'Let us know how we can help.'
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) return

    // No backend needed: hand the enquiry straight to WhatsApp, pre-filled.
    const text = `Hi ${business.name}! I'm ${name} (${contact}).%0A%0A${encodeURIComponent(
      message,
    )}`
    const url = `https://wa.me/${business.whatsapp}?text=${text}`
    window.open(url, '_blank', 'noopener,noreferrer')
    setSent(true)
    form.reset()
  }

  if (sent) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-border bg-background p-10 text-center">
        <span className="flex size-14 items-center justify-center rounded-full bg-whatsapp/15 text-whatsapp">
          <Check className="size-7" />
        </span>
        <h3 className="mt-5 font-display text-2xl font-semibold text-foreground">
          Off it goes!
        </h3>
        <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
          We’ve opened WhatsApp with your message ready to send. Hit send there and we’ll get back
          to you shortly.
        </p>
        <button
          type="button"
          onClick={() => setSent(false)}
          className="mt-6 rounded-full border border-foreground/15 px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:border-foreground/30"
        >
          Send another
        </button>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
      <div>
        <label htmlFor="name" className="mb-1.5 block text-sm font-medium text-foreground">
          Your name
        </label>
        <input id="name" name="name" type="text" autoComplete="name" placeholder="e.g. Aditi Sharma" className={fieldClass} />
        {errors.name && <p className="mt-1.5 text-xs text-destructive">{errors.name}</p>}
      </div>

      <div>
        <label htmlFor="contact" className="mb-1.5 block text-sm font-medium text-foreground">
          Phone or email
        </label>
        <input id="contact" name="contact" type="text" placeholder="Phone number or email address" className={fieldClass} />
        {errors.contact && <p className="mt-1.5 text-xs text-destructive">{errors.contact}</p>}
      </div>

      <div>
        <label htmlFor="message" className="mb-1.5 block text-sm font-medium text-foreground">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          rows={4}
          placeholder="Booking a table, catering, a private event, or just saying hi…"
          className={cn(fieldClass, 'resize-none')}
        />
        {errors.message && <p className="mt-1.5 text-xs text-destructive">{errors.message}</p>}
      </div>

      <button
        type="submit"
        className="group mt-1 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] active:scale-95"
      >
        <Send className="size-4 transition-transform group-hover:translate-x-0.5" />
        Send message
      </button>

      <p className="flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
        <WhatsAppIcon className="size-3.5 text-whatsapp" />
        Sends via WhatsApp — the fastest way to reach us.
      </p>
    </form>
  )
}
