import Image from 'next/image'
import { Reveal } from '@/components/reveal'
import { business } from '@/lib/business'

const points = [
  {
    title: 'Beans with a backstory',
    body: 'We source single-origin beans direct from Indian estates and roast in small batches, so every cup tastes like it should.',
  },
  {
    title: 'Made fresh, not frozen',
    body: 'Our kitchen preps daily and our bakers start before sunrise. If it’s on the counter, it was made this morning.',
  },
  {
    title: 'Built to hang out',
    body: 'Fast Wi-Fi, comfy corners and a playlist that actually slaps. Work, meet or do nothing at all.',
  },
]

export function About() {
  return (
    <section className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        <Reveal className="order-2 lg:order-1">
          <div className="grid grid-cols-2 gap-4">
            <div className="relative mt-8 aspect-[3/4] overflow-hidden rounded-2xl border border-border">
              <Image
                src="/images/latte-art.png"
                alt="Latte with rosetta art"
                fill
                sizes="(max-width: 1024px) 45vw, 22vw"
                className="object-cover"
              />
            </div>
            <div className="relative aspect-[3/4] overflow-hidden rounded-2xl border border-border">
              <Image
                src="/images/pastries.png"
                alt="Fresh croissants and pastries"
                fill
                sizes="(max-width: 1024px) 45vw, 22vw"
                className="object-cover"
              />
            </div>
          </div>
        </Reveal>

        <div className="order-1 flex flex-col justify-center lg:order-2">
          <Reveal as="p" className="text-sm font-semibold uppercase tracking-widest text-primary">
            Why {business.name}
          </Reveal>
          <Reveal as="h2" delay={60} className="mt-3 font-display text-4xl font-semibold leading-tight tracking-tight text-foreground sm:text-5xl text-balance">
            Not another cafe. Your cafe.
          </Reveal>
          <Reveal as="p" delay={120} className="mt-4 max-w-lg text-pretty leading-relaxed text-muted-foreground">
            We started {business.name} with one idea — a place that feels like home but pours coffee
            like a pro. No pretension, no shortcuts. Just really good things, made by people who
            actually love making them.
          </Reveal>

          <div className="mt-8 flex flex-col gap-5">
            {points.map((p, i) => (
              <Reveal key={p.title} delay={160 + i * 80} className="flex gap-4">
                <span className="mt-1 font-display text-xl font-semibold text-primary tabular-nums">
                  0{i + 1}
                </span>
                <div>
                  <h3 className="font-semibold text-foreground">{p.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{p.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
