import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { menu } from '@/lib/menu'

export function MenuPreview() {
  // Show one signature item from each category as a taster.
  const picks = menu.map((cat) => ({
    category: cat.title,
    item: cat.items.find((i) => i.tag) ?? cat.items[0],
  }))

  return (
    <section className="bg-card">
      <div className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <Reveal as="p" className="text-sm font-semibold uppercase tracking-widest text-primary">
              What’s good
            </Reveal>
            <Reveal as="h2" delay={60} className="mt-3 font-display text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">
              A taste of the menu
            </Reveal>
          </div>
          <Reveal delay={100}>
            <Link
              href="/services"
              className="group inline-flex items-center gap-2 rounded-full border border-foreground/15 px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:border-foreground/30"
            >
              Full menu
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
          </Reveal>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {picks.map((pick, i) => (
            <Reveal
              key={pick.category}
              delay={i * 80}
              className="flex flex-col rounded-2xl border border-border bg-background p-6 transition-transform hover:-translate-y-1"
            >
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                {pick.category}
              </p>
              <h3 className="mt-3 font-display text-2xl font-semibold text-foreground">
                {pick.item.name}
              </h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                {pick.item.description}
              </p>
              <p className="mt-4 font-semibold text-primary">{pick.item.price}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
