import { Star } from 'lucide-react'
import { Reveal } from '@/components/reveal'

/* PLACEHOLDER reviews — replace with real Google / Zomato reviews. */
const reviews = [
  {
    quote:
      'Easily my favourite work-from-cafe spot in the city. The flat white is unreal and nobody rushes you out.',
    name: 'Ananya R.',
    meta: 'Regular · Google review',
  },
  {
    quote:
      'Came for coffee, left with three cookies and a new weekend ritual. The brunch is genuinely so good.',
    name: 'Karan M.',
    meta: 'Zomato review',
  },
  {
    quote:
      'We booked it for a small launch party and they nailed everything — food, coffee, playlist, all of it.',
    name: 'Priya & team',
    meta: 'Private event',
  },
]

export function Testimonials() {
  return (
    <section className="bg-olive text-olive-foreground">
      <div className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
        <Reveal as="p" className="text-sm font-semibold uppercase tracking-widest text-olive-foreground/70">
          Loved locally
        </Reveal>
        <Reveal as="h2" delay={60} className="mt-3 max-w-2xl font-display text-4xl font-semibold tracking-tight sm:text-5xl text-balance">
          People keep coming back
        </Reveal>

        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {reviews.map((r, i) => (
            <Reveal
              key={r.name}
              delay={i * 90}
              className="flex flex-col rounded-2xl bg-olive-foreground/10 p-6 ring-1 ring-olive-foreground/15 backdrop-blur-sm"
            >
              <div className="flex">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star key={s} className="size-4 fill-butter text-butter" />
                ))}
              </div>
              <p className="mt-4 flex-1 text-pretty leading-relaxed">“{r.quote}”</p>
              <div className="mt-5">
                <p className="font-semibold">{r.name}</p>
                <p className="text-sm text-olive-foreground/70">{r.meta}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <p className="mt-6 text-xs text-olive-foreground/60">
          * Placeholder reviews — swap these for your real customer quotes.
        </p>
      </div>
    </section>
  )
}
