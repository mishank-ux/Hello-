'use client'

import { useEffect } from 'react'

const CALENDLY_URL = 'https://calendly.com/dhdhdjdnsnn/30min'

declare global {
  interface Window {
    Calendly?: {
      initBadgeWidget: (opts: {
        url: string
        text: string
        color: string
        textColor: string
        branding?: boolean
      }) => void
    }
  }
}

export function CalendlyBadge() {
  useEffect(() => {
    const cssId = 'calendly-widget-css'
    if (!document.getElementById(cssId)) {
      const link = document.createElement('link')
      link.id = cssId
      link.rel = 'stylesheet'
      link.href = 'https://assets.calendly.com/assets/external/widget.css'
      document.head.appendChild(link)
    }

    // Show the badge on Home. Calendly's initBadgeWidget can only run once per
    // session, so if the badge node already exists we just un-hide it instead
    // of re-initializing (re-initializing throws).
    function showBadge() {
      const existing = document.querySelector('.calendly-badge-widget') as HTMLElement | null
      if (existing) {
        existing.style.display = ''
        return
      }
      window.Calendly?.initBadgeWidget({
        url: CALENDLY_URL,
        text: 'Book an appointment',
        // Matches the site's terracotta accent (--primary)
        color: '#c15a38',
        textColor: '#ffffff',
        branding: true,
      })
    }

    const scriptId = 'calendly-widget-js'
    const existingScript = document.getElementById(scriptId) as HTMLScriptElement | null
    if (existingScript) {
      if (window.Calendly) showBadge()
      else existingScript.addEventListener('load', showBadge)
    } else {
      const script = document.createElement('script')
      script.id = scriptId
      script.src = 'https://assets.calendly.com/assets/external/widget.js'
      script.async = true
      script.addEventListener('load', showBadge)
      document.body.appendChild(script)
    }

    return () => {
      // Leaving Home: hide the badge (keep the node so Calendly's state stays
      // intact) so it never appears on the Menu or Contact pages.
      const badge = document.querySelector('.calendly-badge-widget') as HTMLElement | null
      if (badge) badge.style.display = 'none'
    }
  }, [])

  return null
}
