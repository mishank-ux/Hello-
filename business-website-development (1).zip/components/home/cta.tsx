import Link from 'next/link'
import { Phone, ArrowRight } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { business, telUrl, whatsappUrl } from '@/lib/business'
import { WhatsAppIcon } from '@/components/brand-icons'

export function CTA() {
  return (
    <section className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
      <Reveal className="relative overflow-hidden rounded-[2rem] bg-foreground px-6 py-14 text-background sm:px-14 sm:py-20">
        <div className="relative z-10 max-w-2xl">
          <h2 className="font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl text-balance">
            Swing by, or say hi first.
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-background/70">
            We’re open all day at {business.address.line1}. Call to book a table, message us on
            WhatsApp for orders, or just show up — we’ll put the kettle on.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href={telUrl}
              className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-105 active:scale-95"
            >
              <Phone className="size-4" />
              Call Now
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-whatsapp px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:scale-105 active:scale-95"
            >
              <WhatsAppIcon className="size-4" />
              WhatsApp us
            </a>
            <Link
              href="/contact"
              className="group inline-flex items-center gap-2 rounded-full border border-background/25 px-6 py-3.5 text-sm font-semibold text-background transition-colors hover:border-background/50"
            >
              Find us
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
          </div>
        </div>
        <div
          aria-hidden
          className="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full bg-primary/25 blur-2xl"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-20 right-24 size-56 rounded-full bg-olive/30 blur-2xl"
        />
      </Reveal>
    </section>
  )
}
