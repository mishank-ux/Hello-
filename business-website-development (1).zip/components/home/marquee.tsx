const words = [
  'specialty coffee',
  'all-day brunch',
  'fresh bakes',
  'free wi-fi',
  'good playlists',
  'great company',
]

export function Marquee() {
  const row = [...words, ...words]
  return (
    <div className="border-y border-border bg-primary py-3 text-primary-foreground">
      <div className="flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
        <ul className="flex shrink-0 animate-[marquee_28s_linear_infinite] items-center gap-8 pr-8">
          {row.map((w, i) => (
            <li key={i} className="flex items-center gap-8 whitespace-nowrap font-display text-lg font-medium">
              {w}
              <span aria-hidden className="size-1.5 rounded-full bg-primary-foreground/50" />
            </li>
          ))}
        </ul>
        <ul
          aria-hidden
          className="flex shrink-0 animate-[marquee_28s_linear_infinite] items-center gap-8 pr-8"
        >
          {row.map((w, i) => (
            <li key={i} className="flex items-center gap-8 whitespace-nowrap font-display text-lg font-medium">
              {w}
              <span className="size-1.5 rounded-full bg-primary-foreground/50" />
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
