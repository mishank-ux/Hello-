import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, Phone, Star, MapPin } from 'lucide-react'
import { business, telUrl } from '@/lib/business'

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto grid w-full max-w-6xl items-center gap-10 px-5 pb-10 pt-10 sm:px-8 sm:pt-14 lg:grid-cols-[1.05fr_1fr] lg:gap-12 lg:pb-16">
        <div className="flex flex-col">
          <span className="inline-flex w-fit items-center gap-2 rounded-full border border-border bg-card px-3.5 py-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            <span className="size-2 rounded-full bg-whatsapp" />
            Now open · {business.address.line2.split(',')[1]?.trim() ?? 'Bengaluru'}
          </span>

          <h1 className="mt-5 font-display text-[clamp(2.75rem,8vw,5rem)] font-semibold leading-[0.95] tracking-tight text-foreground text-balance">
            good coffee,
            <br />
            <span className="text-primary">great company.</span>
          </h1>

          <p className="mt-5 max-w-md text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            {business.name} is your all-day hangout for specialty brews, fresh brunch and
            baked-this-morning treats. Come for the coffee, stay for the vibe.
          </p>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            <Link
              href="/services"
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition-transform hover:scale-105 active:scale-95"
            >
              See the menu
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
            <a
              href={telUrl}
              className="inline-flex items-center gap-2 rounded-full border border-foreground/15 bg-card px-6 py-3.5 text-sm font-semibold text-foreground transition-colors hover:border-foreground/30"
            >
              <Phone className="size-4 text-primary" />
              Call Now
            </a>
          </div>

          <div className="mt-8 flex items-center gap-5 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-4 fill-butter text-butter" />
                ))}
              </div>
              <span className="font-medium text-foreground">4.9</span>
              <span>· 800+ regulars</span>
            </div>
            <span className="hidden items-center gap-1.5 sm:flex">
              <MapPin className="size-4 text-primary" />
              {business.address.line1}
            </span>
          </div>
        </div>

        <div className="relative">
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] border border-border shadow-xl shadow-black/5 sm:aspect-[5/5]">
            <Image
              src="/images/hero-cafe.png"
              alt={`Inside ${business.name} cafe`}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 45vw"
              className="object-cover"
            />
          </div>
          <div className="absolute -bottom-4 -left-3 rotate-[-4deg] rounded-2xl bg-olive px-4 py-3 text-olive-foreground shadow-lg sm:-left-5">
            <p className="font-display text-lg font-semibold leading-none">roasted daily</p>
            <p className="mt-1 text-xs opacity-80">small-batch beans</p>
          </div>
        </div>
      </div>
    </section>
  )
}
