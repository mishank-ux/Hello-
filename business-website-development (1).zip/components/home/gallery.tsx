import Image from 'next/image'
import { Reveal } from '@/components/reveal'

const shots = [
  { src: '/images/hero-cafe.png', alt: 'Cafe interior in golden light', span: 'sm:col-span-2 sm:row-span-2' },
  { src: '/images/brunch-plate.png', alt: 'Masala egg brunch plate', span: '' },
  { src: '/images/latte-art.png', alt: 'Latte art in a ceramic cup', span: '' },
  { src: '/images/pastries.png', alt: 'Tray of fresh croissants', span: 'sm:col-span-2' },
]

export function Gallery() {
  return (
    <section className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
      <Reveal as="p" className="text-sm font-semibold uppercase tracking-widest text-primary">
        The vibe
      </Reveal>
      <Reveal as="h2" delay={60} className="mt-3 max-w-2xl font-display text-4xl font-semibold tracking-tight text-foreground sm:text-5xl text-balance">
        A little look around
      </Reveal>

      <Reveal delay={120} className="mt-10">
        <div className="grid auto-rows-[160px] grid-cols-2 gap-3 sm:auto-rows-[200px] sm:grid-cols-4">
          {shots.map((shot) => (
            <div
              key={shot.src + shot.alt}
              className={`relative overflow-hidden rounded-2xl border border-border ${shot.span}`}
            >
              <Image
                src={shot.src}
                alt={shot.alt}
                fill
                sizes="(max-width: 640px) 50vw, 25vw"
                className="object-cover transition-transform duration-500 hover:scale-105"
              />
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  )
}
